<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Tabungan Saya</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    date_default_timezone_set('Asia/Jakarta');
?>
<div class="row">
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-cyan">
                        <i class="anticon anticon-rise"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $setoran = $this->db->query('SELECT SUM(jumlah) AS jumlahSetoran FROM tb_transaksi WHERE jenis="Setoran" AND idUser="'.$this->session->userdata('id').'" ');
                                foreach ($setoran->result() as $str) {
                                    echo 'Rp. ' . number_format($str->jumlahSetoran,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Setoran</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-purple">
                        <i class="anticon anticon-fall"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                        <?php
                                $penarikan = $this->db->query('SELECT SUM(jumlah) AS jumlahPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND idUser="'.$this->session->userdata('id').'" ');
                                foreach ($penarikan->result() as $pnr) {
                                    echo 'Rp. ' . number_format($pnr->jumlahPenarikan,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Penarikan</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-gold">
                        <i class="anticon anticon-dollar"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                echo 'Rp. ' . number_format($str->jumlahSetoran - $pnr->jumlahPenarikan,0,',','.');
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Saldo</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th width="15px">#</th>
                        <th>Tanggal</th>
                        <th>Jenis Transaksi</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        foreach ($tabungan->result_array() as $row) {
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= date('d F Y H:i', strtotime($row['tgl'])) ?></td>
                            <td>
                                <?php
                                    if ($row['jenis'] == 'Setoran') {
                                        echo '<div class="badge badge-success">'.$row['jenis'].'</div>';
                                    } elseif ($row['jenis'] == 'Penarikan'){
                                        echo '<div class="badge badge-danger">'.$row['jenis'].'</div>';
                                    }
                                ?>
                            </td>
                            <td>Rp. <?= number_format($row['jumlah'],0,',','.') ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>