<!-- Side Nav START -->
<div class="side-nav">
    <div class="side-nav-inner">
        <ul class="side-nav-menu scrollable">
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="<?= base_url('index.php/siswa/dashboard') ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-dashboard"></i>
                    </span>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="<?= base_url('index.php/siswa/tabungan') ?>">
                    <span class="icon-holder">
                        <i class="anticon anticon-dollar"></i>
                    </span>
                    <span class="title">Tabungan Saya</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="dropdown-toggle tombol-yakin" href="<?= base_url('index.php/home/logout') ?>" data-isidata="Ingin keluar dari sistem ini?">
                    <span class="icon-holder">
                        <i class="anticon anticon-logout"></i>
                    </span>
                    <span class="title">Logout</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- Side Nav END -->

<!-- Page Container START -->
<div class="page-container">

<!-- Content Wrapper START -->
<div class="main-content">