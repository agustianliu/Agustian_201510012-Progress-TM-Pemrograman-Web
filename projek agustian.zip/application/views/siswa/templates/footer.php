            </div>
            <!-- Content Wrapper END -->
                <!-- Footer START -->
                <footer class="footer">
                    <div class="footer-content">
                        <p class="m-b-0">Copyright © <?= date('Y') ?> <a href="https://www.instagram.com/agustianliuu/" target="blank">Agustian-201510012</a>. All rights reserved.</p>
                        <span>
                            <font class="text-gray m-r-15">V 1.0.0</font>
                        </span>
                    </div>
                </footer>
                <!-- Footer END -->

            </div>
            <!-- Page Container END -->
        </div>
    </div>

    <!-- Core Vendors JS -->
    <script src="<?= base_url() ?>assets/js/vendors.min.js"></script>

    <!-- page js -->
    <script src="<?= base_url() ?>assets/vendors/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>assets/vendors/datatables/dataTables.bootstrap.min.js"></script>
    <script>
        $('#data-table').DataTable();
    </script>

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        $(document).ready(function() {
            const flashData = $('.flash-data').data('flashdata');
            if (flashData){
                Swal.fire({
                    icon: 'success',
                    title: 'Good job!',
                    text: flashData,
                })
            }
        });

        $('.tombol-yakin').on('click', function (e) {
            e.preventDefault();
            const href = $(this).attr('href');
            const isiData = $(this).data('isidata');
            Swal.fire({
                title: 'Are you sure?',
                text: isiData,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'OK!'
            }).then((result) => {
            if (result.isConfirmed) {
                document.location.href = href;
            }
            });
        });
    </script>

    <!-- Core JS -->
    <script src="<?= base_url() ?>assets/js/app.min.js"></script>

</body>

</html>