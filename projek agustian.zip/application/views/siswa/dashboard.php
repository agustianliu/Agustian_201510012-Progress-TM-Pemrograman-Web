<div class="page-header no-gutters">
    <div class="d-md-flex align-items-md-center justify-content-between">
        <div class="media m-v-10 align-items-center">
            <div class="avatar avatar-image avatar-lg">
                <img src="<?= base_url() ?>assets/images/avatars/thumb-3.png" alt="">
            </div>
            <div class="media-body m-l-15">
                <h4 class="m-b-0">Selamat Datang, <?= $this->session->userdata('nama') ?>!</h4>
                <span class="text-gray"><?= $this->session->userdata('level') ?></span>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-cyan">
                        <i class="anticon anticon-rise"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $setoran = $this->db->query('SELECT SUM(jumlah) AS jumlahSetoran FROM tb_transaksi WHERE jenis="Setoran" AND idUser="'.$this->session->userdata('id').'" ');
                                foreach ($setoran->result() as $str) {
                                    echo 'Rp. ' . number_format($str->jumlahSetoran,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Setoran</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-purple">
                        <i class="anticon anticon-fall"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                        <?php
                                $penarikan = $this->db->query('SELECT SUM(jumlah) AS jumlahPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND idUser="'.$this->session->userdata('id').'" ');
                                foreach ($penarikan->result() as $pnr) {
                                    echo 'Rp. ' . number_format($pnr->jumlahPenarikan,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Penarikan</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-gold">
                        <i class="anticon anticon-dollar"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                echo 'Rp. ' . number_format($str->jumlahSetoran - $pnr->jumlahPenarikan,0,',','.');
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Saldo</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6 col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-blue">
                        <i class="anticon anticon-login"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND idUser="'.$this->session->userdata('id').'" AND MONTH(tgl) ="'.date('m').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Setoran (<?= date('F Y') ?>)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-red">
                        <i class="anticon anticon-logout"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND idUser="'.$this->session->userdata('id').'" AND MONTH(tgl) ="'.date('m').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Penarikan (<?= date('F Y') ?>)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>