<div class="page-header no-gutters has-tab">
    <h2 class="font-weight-normal">Edit Profil</h2>
    <ul class="nav nav-tabs" >
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#tab-account">Account</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#tab-password">Change Password</a>
        </li>
    </ul>
</div>
<div class="container">
    <div class="tab-content m-t-15">
        <div class="tab-pane fade show active" id="tab-account" >
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Account</h4>
                </div>
                <form action="<?= base_url('index.php/siswa/profil/account/').$this->session->userdata('id') ?>" method="POST">
                    <div class="card-body">
                        <div class="form-group">
                            <label>NIS</label>
                            <input type="text" class="form-control" value="<?= $this->session->userdata('username') ?>" disabled required>
                        </div>
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" value="<?= $this->session->userdata('nama') ?>" placeholder="Username" required>
                        </div>
                        <?php foreach ($siswa->result_array() as $row) { ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Tanggal Lahir</label>
                                        <input type="date" class="form-control" name="tglLahir" value="<?= $row['tglLahir'] ?>" placeholder="Username" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Jenis Kelamin</label>
                                        <select name="jenisKelamin" class="form-control" required>
                                            <?php if($row['jenisKelamin'] == 'Laki-Laki') { ?>
                                                <option value="Laki-Laki" selected>Laki-Laki</option>
                                                <option value="Perempuan">Perempuan</option>
                                            <?php } else { ?>
                                                <option value="Laki-Laki">Laki-Laki</option>
                                                <option value="Perempuan" selected>Perempuan</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Change
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="tab-pane fade show" id="tab-password" >
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Change Password</h4>
                </div>
                <form action="<?= base_url('index.php/siswa/profil/password/').$this->session->userdata('id') ?>" method="POST">
                    <div class="card-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" name="password" placeholder="New Password" required>
                        </div>
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Change
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>