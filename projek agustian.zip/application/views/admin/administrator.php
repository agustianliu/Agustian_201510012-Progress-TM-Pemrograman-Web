<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-8">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Data Administrator</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="text-md-right m-v-10">
                <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">Tambah Data</span>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th width="15px">#</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Level</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        foreach ($user->result_array() as $row) {
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $row['nama'] ?></td>
                            <td><?= $row['username'] ?></td>
                            <td><?= $row['level'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="tambahData">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Data Administrator</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <i class="anticon anticon-close"></i>
                </button>
            </div>
            <form action="<?= base_url('index.php/admin/administrator/insert') ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                        <label>Level</label>
                        <select name="level" class="form-control" required>
                            <option value="" disabled selected> -- Pilih Level -- </option>
                            <option value="Administrator">Administrator</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger">
                        <div class="fas fa-trash"></div> Reset
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <div class="fas fa-save"></div> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>