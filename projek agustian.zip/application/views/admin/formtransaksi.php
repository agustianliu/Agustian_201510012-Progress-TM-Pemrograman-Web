<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Tambah Transaksi</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <button class="btn btn-primary" onclick="history.back(-1)">
                    <i class="anticon anticon-caret-left"></i>
                    <span class="m-l-5">Kembali</span>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <form action="<?= base_url('index.php/admin/transaksi/insert') ?>" method="POST">
            <div class="card-body">
                <div class="form-group">
                    <label>Siswa</label>
                    <select name="idUser" class="form-control select2" required>
                        <option value="" disabled selected>-- Pilih Siswa --</option>
                        <?php foreach ($siswa->result() as $swa) { ?>
                            <option value="<?= $swa->id; ?>"><?= $swa->username . ' - ' . $swa->nama; ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jenis</label>
                    <select name="jenis" class="form-control" required>
                        <option value="" disabled selected>-- Pilih Jenis --</option>
                        <option value="Setoran">Setoran</option>
                        <option value="Penarikan">Penarikan</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah</label>
                    <input type="text" name="jumlah" class="form-control" id="rupiah1" placeholder="Jumlah Tunai" required>
                </div>
                <button type="reset" class="btn btn-danger">
                    <div class="fas fa-trash"></div> Reset
                </button>
                <button type="submit" class="btn btn-primary">
                    <div class="fas fa-save"></div> Save
                </button>
            </div>
        </form>
    </div>
</div>