<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Data Kelas</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">Tambah Data</span>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th width="15px">#</th>
                        <th>Kode Kelas</th>
                        <th>Nama Kelas</th>
                        <th>Jumlah Siswa</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        foreach ($kelas->result_array() as $row) {
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $row['kode']; ?></td>
                            <td><?= $row['kelas']; ?></td>
                            <td>
                                <?php
                                    $this->db->where('idKelas', $row['id']);
                                    $jmlSiswa = $this->db->get('tb_siswa');
                                    echo $jmlSiswa->num_rows() . ' Siswa';
                                ?>
                            </td>
                            <td>
                                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editData<?= $row['id'] ?>">
                                    <div class="fas fa-edit fa-sm"></div> Edit
                                </button>
                                <a href="<?= base_url('index.php/admin/kelas/delete/').$row['id'] ?>" class="btn btn-danger btn-sm tombol-yakin" data-isidata="Ingin menghapus kelas ini? akan berpengaruh pada data yang lain">
                                    <div class="fas fa-trash fa-sm"></div> Delete
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="tambahData">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Data Kelas</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <i class="anticon anticon-close"></i>
                </button>
            </div>
            <form action="<?= base_url('index.php/admin/kelas/insert') ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Kode Kelas</label>
                        <input type="text" name="kode" class="form-control" placeholder="Kode Kelas" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Kelas</label>
                        <input type="text" name="kelas" class="form-control" placeholder="Nama Kelas" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger">
                        <div class="fas fa-trash"></div> Reset
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <div class="fas fa-save"></div> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($kelas->result() as $kls) { ?>
    <div class="modal fade" id="editData<?= $kls->id ?>">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Kelas</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <i class="anticon anticon-close"></i>
                    </button>
                </div>
                <form action="<?= base_url('index.php/admin/kelas/update/').$kls->id ?>" method="POST">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Kode Kelas</label>
                            <input type="text" name="kode" class="form-control" value="<?= $kls->kode; ?>" placeholder="Kode Kelas" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Kelas</label>
                            <input type="text" name="kelas" class="form-control" value="<?= $kls->kelas; ?>" placeholder="Nama Kelas" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>