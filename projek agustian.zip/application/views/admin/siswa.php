<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Data Siswa</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">Tambah Data</span>
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>NIS</th>
                        <th>Nama Lengkap</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>Kelas</th>
                        <th>Saldo</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        foreach ($siswa->result_array() as $row) {
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <?php
                                    $this->db->where('id', $row['idUser']);
                                    $user = $this->db->get('tb_user');
                                    foreach ($user->result() as $dUsr) {
                                        echo $dUsr->username;
                                    }
                                ?>
                            </td>
                            <td><?= $dUsr->nama; ?></td>
                            <td><?= date('d F Y', strtotime($row['tglLahir'])) ?></td>
                            <td><?= $row['jenisKelamin'] ?></td>
                            <td>
                                <?php
                                    $this->db->where('id', $row['idKelas']);
                                    $dataKelas = $this->db->get('tb_kelas');
                                    foreach ($dataKelas->result() as $dKls) {
                                        echo $dKls->kode . '-' . $dKls->kelas;
                                    }
                                ?>
                            </td>
                            <td>
                                <?php
                                    $setoran = $this->db->query('SELECT SUM(jumlah) AS totalSetoran FROM tb_transaksi WHERE jenis="Setoran" AND idUser="'.$row['idUser'].'" ');
                                    foreach ($setoran->result() as $tStr) {}

                                    $penarikan = $this->db->query('SELECT SUM(jumlah) AS totalPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND idUser="'.$row['idUser'].'" ');
                                    foreach ($penarikan->result() as $tPnr) {}

                                    echo 'Rp. ' . number_format($tStr->totalSetoran - $tPnr->totalPenarikan,0,',','.');
                                ?>
                            </td>
                            <td>
                                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editData<?= $row['id'] ?>">
                                    <div class="fas fa-edit fa-sm"></div> Edit
                                </button>
                                <a href="<?= base_url('index.php/admin/siswa/delete/').$row['id'] ?>" class="btn btn-danger btn-sm tombol-yakin" data-isidata="Ingin menghapus siswa ini? Akan berpengaruh pada data transaksi">
                                    <div class="fas fa-trash fa-sm"></div> Delete
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="tambahData">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Data Siswa</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <i class="anticon anticon-close"></i>
                </button>
            </div>
            <form action="<?= base_url('index.php/admin/siswa/insert') ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>NIS</label>
                        <input type="text" name="nis" class="form-control" placeholder="Nomor Induk Siswa" required>
                    </div>
                    <div class="form-group">
                        <label>Nama Lengkap</label>
                        <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tgl Lahir</label>
                                <input type="date" name="tglLahir" class="form-control" placeholder="Nama Lengkap" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Jenis Kelamin</label>
                                <select name="jenisKelamin" class="form-control" required>
                                    <option value="" disabled selected> -- Pilih Jenis Kelamin -- </option>
                                    <option value="Laki-Laki">Laki-Laki</option>
                                    <option value="Perempuan">Perempuan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Kelas</label>
                                <select name="idKelas" class="form-control" required>
                                    <option value="" disabled selected> -- Pilih Kelas -- </option>
                                    <?php foreach ($kelas->result() as $kls) { ?>
                                        <option value="<?= $kls->id; ?>"><?= $kls->kode . ' - ' . $kls->kelas; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger">
                        <div class="fas fa-trash"></div> Reset
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <div class="fas fa-save"></div> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($siswa->result() as $eSwa) { ?>
    <div class="modal fade" id="editData<?= $eSwa->id ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Siswa</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <i class="anticon anticon-close"></i>
                    </button>
                </div>
                <form action="<?= base_url('index.php/admin/siswa/update') ?>" method="POST">
                    <div class="modal-body">
                        <?php
                            $this->db->where('id', $eSwa->idUser);
                            foreach ($this->db->get('tb_user')->result() as $eUsr) {
                            }
                        ?>
                        <div class="form-group">
                            <label>NIS</label>
                            <input type="hidden" name="id" class="form-control" value="<?= $eSwa->id ?>" required>
                            <input type="hidden" name="idUser" class="form-control" value="<?= $eSwa->idUser ?>" required>
                            <input type="text" name="nis" class="form-control" value="<?= $eUsr->username ?>" placeholder="Nomor Induk Siswa" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control" value="<?= $eUsr->nama ?>" placeholder="Nama Lengkap" required>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Tgl Lahir</label>
                                    <input type="date" name="tglLahir" class="form-control" value="<?= $eSwa->tglLahir ?>" placeholder="Nama Lengkap" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Jenis Kelamin</label>
                                    <select name="jenisKelamin" class="form-control" required>
                                        <?php if($eSwa->jenisKelamin == 'Laki-Laki') { ?>
                                            <option value="Laki-Laki">Laki-Laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                        <?php } else { ?>
                                            <option value="Perempuan">Perempuan</option>
                                            <option value="Laki-Laki">Laki-Laki</option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Kelas</label>
                                    <select name="idKelas" class="form-control" required>
                                        <option value="<?= $eSwa->idKelas ?>">
                                            <?php
                                                $this->db->where('id', $eSwa->idKelas);
                                                foreach ($this->db->get('tb_kelas')->result() as $eKls) {
                                                    echo $eKls->kode . ' - ' . $eKls->kelas;
                                                }
                                            ?>
                                        </option>
                                        <option value="" disabled> -- Pilih Kelas Lain-- </option>
                                        <?php foreach ($kelas->result() as $kls) { ?>
                                            <option value="<?= $kls->id; ?>"><?= $kls->kode . ' - ' . $kls->kelas; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>