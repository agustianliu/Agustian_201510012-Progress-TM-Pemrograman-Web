<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <div class="input-affix m-v-10">
                        <h2 class="font-weight-normal">Data Transaksi</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <a href="<?= base_url('index.php/admin/transaksi/add') ?>" class="btn btn-primary">
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">Tambah Data</span>
                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th width="15px">#</th>
                        <th>NIS</th>
                        <th>Nama Lengkap</th>
                        <th>Jenis</th>
                        <th>Jumlah</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        date_default_timezone_set('Asia/Jakarta');
                        foreach ($transaksi->result_array() as $row) {
                    ?>
                        <tr>
                            <td><?= $no++; ?></td>
                                <?php
                                    $this->db->where('id', $row['idUser']);
                                    $user = $this->db->get('tb_user');
                                    foreach ($user->result() as $usr) { }
                                ?>
                                <td><?= $usr->username; ?></td>
                                <td><?= $usr->nama; ?></td>
                            <td>
                                <?php
                                    if ($row['jenis'] == 'Setoran') {
                                        echo '<div class="badge badge-success">'.$row['jenis'].'</div>';
                                    } elseif ($row['jenis'] == 'Penarikan'){
                                        echo '<div class="badge badge-danger">'.$row['jenis'].'</div>';
                                    }
                                ?>
                            </td>
                            <td>Rp. <?= number_format($row['jumlah'],0,',','.') ?></td>
                            <td><?= date('d M Y H:i', strtotime($row['tgl'])) ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editData<?= $row['id'] ?>">
                                    <div class="fa fa-edit"></div> Edit
                                </button>
                                <a href="<?= base_url('index.php/admin/transaksi/delete/').$row['id'] ?>" class="btn btn-danger btn-sm tombol-yakin" data-isidata="Ingin menghapus transaksi ini?">
                                    <div class="fas fa-trash fa-sm"></div> Delete
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($transaksi->result() as $eTrs) { ?>
    <div class="modal fade" id="editData<?= $eTrs->id ?>">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Transaksi</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <i class="anticon anticon-close"></i>
                    </button>
                </div>
                <form action="<?= base_url('index.php/admin/transaksi/update/').$eTrs->id ?>" method="POST">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Jumlah</label>
                            <input type="number" name="jumlah" class="form-control" value="<?= $eTrs->jumlah ?>" placeholder="Jumlah" required>
                        </div>
                        <div class="form-group">
                            <label>Jenis</label>
                            <select name="jenis" class="form-control">
                                <?php if($eTrs->jenis == 'Setoran') { ?>
                                    <option value="Setoran">Setoran</option>
                                    <option value="Penarikan">Penarikan</option>
                                <?php } else { ?>
                                    <option value="Penarikan">Penarikan</option>
                                    <option value="Setoran">Setoran</option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>