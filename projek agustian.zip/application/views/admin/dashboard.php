<div class="page-header no-gutters">
    <div class="d-md-flex align-items-md-center justify-content-between">
        <div class="media m-v-10 align-items-center">
            <div class="avatar avatar-image avatar-lg">
                <img src="<?= base_url() ?>assets/images/avatars/thumb-3.png" alt="">
            </div>
            <div class="media-body m-l-15">
                <h4 class="m-b-0">Selamat Datang, <?= $this->session->userdata('nama') ?>!</h4>
                <span class="text-gray"><?= $this->session->userdata('level') ?></span>
            </div>
        </div>
    </div>
</div>
<?php
    date_default_timezone_set('Asia/Jakarta');
?>
<div class="row">
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-cyan">
                        <i class="anticon anticon-layout"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $jumlahKelas = $this->db->query('SELECT id FROM tb_kelas');
                                echo $jumlahKelas->num_rows();
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Data Kelas</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-purple">
                        <i class="anticon anticon-user"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $jumlahSiswa = $this->db->query('SELECT id FROM tb_siswa');
                                echo $jumlahSiswa->num_rows();
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Siswa</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-blue">
                        <i class="anticon anticon-team"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $jumlahAdmin = $this->db->query('SELECT id FROM tb_user WHERE level="Administrator" ');
                                echo $jumlahAdmin->num_rows();
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Administrator</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-gold">
                        <i class="anticon anticon-dollar"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $setoran = $this->db->query('SELECT SUM(jumlah) AS jumlahSetoran FROM tb_transaksi WHERE jenis="Setoran"');
                                foreach ($setoran->result() as $str) {}
                                
                                $penarikan = $this->db->query('SELECT SUM(jumlah) AS jumlahPenarikan FROM tb_transaksi WHERE jenis="Penarikan"');
                                foreach ($penarikan->result() as $prn) {}

                                $bonus = $this->db->query('SELECT SUM(jumlah) AS jumlahBonus FROM tb_transaksi WHERE jenis="Bonus"');
                                foreach ($bonus->result() as $bns) {}

                                echo 'Rp. ' . number_format(($str->jumlahSetoran - $prn->jumlahPenarikan) + $bns->jumlahBonus,0,',','.');
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Saldo Total</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-6 col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-blue">
                        <i class="anticon anticon-login"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND YEAR(tgl) ="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Setoran (<?= date('Y') ?>)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-6">
        <div class="card">
            <div class="card-body">
                <div class="media align-items-center">
                    <div class="avatar avatar-icon avatar-lg avatar-red">
                        <i class="anticon anticon-logout"></i>
                    </div>
                    <div class="m-l-15">
                        <h2 class="m-b-0">
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND YEAR(tgl) ="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </h2>
                        <p class="m-b-0 text-muted">Total Penarikan (<?= date('Y') ?>)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table id="data-table" class="table table-bordered">
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th>Setoran</th>
                        <th>Penarikan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Januari - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="01" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="01" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Februari - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="02" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="02" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Maret - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="03" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="03" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>April - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="04" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="04" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Mei - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="05" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="05" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Juni - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="06" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="06" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Juli - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="07" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="07" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Agustus - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="08" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="08" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>September - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="09" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="09" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Oktober - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="10" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="10" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>November - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="11" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="11" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Desember - <?= date('Y') ?></td>
                        <td>
                            <?php
                                $totalSetoran = $this->db->query('SELECT sum(jumlah) AS tSetoran FROM tb_transaksi WHERE jenis="Setoran" AND MONTH(tgl) ="12" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalSetoran->result() as $dStr) {
                                    echo 'Rp. ' . number_format($dStr->tSetoran,0,',','.');
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $totalPenarikan = $this->db->query('SELECT sum(jumlah) AS tPenarikan FROM tb_transaksi WHERE jenis="Penarikan" AND MONTH(tgl) ="12" AND YEAR(tgl)="'.date('Y').'" ');
                                foreach($totalPenarikan->result() as $dPnr) {
                                    echo 'Rp. ' . number_format($dPnr->tPenarikan,0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>