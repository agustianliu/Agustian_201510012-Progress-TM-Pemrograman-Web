<div class="page-header no-gutters has-tab">
    <h2 class="font-weight-normal">Edit Profil</h2>
    <ul class="nav nav-tabs" >
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#tab-account">Account</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#tab-password">Change Password</a>
        </li>
    </ul>
</div>
<div class="container">
    <div class="tab-content m-t-15">
        <div class="tab-pane fade show active" id="tab-account" >
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Account</h4>
                </div>
                <form action="<?= base_url('index.php/admin/profil/account/').$this->session->userdata('id') ?>" method="POST">
                    <div class="card-body">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" name="username" value="<?= $this->session->userdata('username') ?>" placeholder="Username" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" class="form-control" name="nama" value="<?= $this->session->userdata('nama') ?>" placeholder="Username" required>
                        </div>
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Change
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="tab-pane fade show" id="tab-password" >
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Change Password</h4>
                </div>
                <form action="<?= base_url('index.php/admin/profil/password/').$this->session->userdata('id') ?>" method="POST">
                    <div class="card-body">
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" name="password" placeholder="New Password" required>
                        </div>
                        <button type="reset" class="btn btn-danger">
                            <div class="fas fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fas fa-save"></div> Change
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>