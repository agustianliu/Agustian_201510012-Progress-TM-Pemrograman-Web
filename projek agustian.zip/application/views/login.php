<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sign in - Tabungan Siswa</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?= base_url() ?>assets/images/logo/favicon.png">

    <!-- Sweet Alert -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css">

    <!-- Core css -->
    <link href="<?= base_url() ?>assets/css/app.min.css" rel="stylesheet">

</head>

<body>
    <div class="app">
        <div class="flash-data" data-flashdata="<?= $this->session->flashdata('pesan') ?>"></div>
        <div class="container-fluid p-h-0 p-v-20 bg full-height d-flex" style="background-image: url('<?= base_url() ?>assets/images/others/login-3.png')">
            <div class="d-flex flex-column justify-content-between w-100">
                <div class="container d-flex h-100">
                    <div class="row align-items-center w-100">
                        <div class="col-md-7 col-lg-5 m-h-auto">
                            <div class="card shadow-lg">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between m-b-30">
                                        <img class="img-fluid" alt="" src="<?= base_url() ?>assets/images/logo/logo.png">
                                        <h2 class="m-b-0">Sign In</h2>
                                    </div>
                                    <form action="<?= base_url('index.php/home/auth') ?>" method="POSt">
                                        <div class="form-group">
                                            <label class="font-weight-semibold">Username <font color="red">*</font>:</label>
                                            <div class="input-affix">
                                                <i class="prefix-icon anticon anticon-user"></i>
                                                <input type="text" name="username" class="form-control" placeholder="Username" required autofocus>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="font-weight-semibold">Password <font color="red">*</font>:</label>
                                            <div class="input-affix m-b-10">
                                                <i class="prefix-icon anticon anticon-lock"></i>
                                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="font-weight-semibold" for="password">Captcha:</label>
                                            <font class="float-right font-size-13 text-muted"><?= $hitung; ?></font>
                                            <div class="input-affix m-b-10">
                                                <i class="prefix-icon anticon anticon-robot"></i>
                                                <input type="text" name="jawaban" class="form-control" placeholder="Captcha">
                                            </div>
                                        </div>
                                        <font color="red">* <small>Wajib diisi!</small></font>
                                        <button type="submit" class="btn btn-primary float-right">
                                            <div class="fas fa-sign-in-alt"></div> Sign In
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-none d-md-flex p-h-40 justify-content-between">
                    <span class="">© <?= date('Y') ?> <a href="https://www.instagram.com/agustianliuu/" target="blank">AGUSTIAN-201510012</a></span>
                </div>
            </div>
        </div>
    </div>

    
    <!-- Core Vendors JS -->
    <script src="<?= base_url() ?>assets/js/vendors.min.js"></script>

    <!-- Core JS -->
    <script src="<?= base_url() ?>assets/js/app.min.js"></script>

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        $(document).ready(function() {
            const flashData = $('.flash-data').data('flashdata');
            if (flashData){
                Swal.fire({
                    icon: 'error',
                    title: 'Oops....',
                    text: flashData,
                })
            }
        });
    </script>

</body>

</html>