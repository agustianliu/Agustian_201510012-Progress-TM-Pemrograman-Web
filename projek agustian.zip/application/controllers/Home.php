<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
        if(!$this->session->userdata('level')) {
            $digit1 = mt_rand(1, 20);
            $digit2 = mt_rand(1, 20);
            $jumlahCaptcha = $digit1+$digit2;
            $data = array('captcha' => $jumlahCaptcha);
            $this->session->set_userdata($data);
            $captcha = $digit1 . ' + ' . $digit2 . ' = ?';
            $data['hitung'] = $captcha;

            $this->load->view('login', $data);
        } elseif ($this->session->userdata('level') == 'Administrator') {
            redirect('admin/dashboard');
        } elseif ($this->session->userdata('level') == 'Siswa') {
            redirect('siswa/dashboard');
        }
    }
    
    public function auth()
    {
        $username   = $_POST['username'];
        $password   = $_POST['password'];
        $jawaban    = $_POST['jawaban'];
        
        if (empty($jawaban)) {
            $this->session->set_flashdata('pesan', 'Captcha harap diisi!');
            redirect('home');
        } else {
            if($jawaban == $this->session->userdata('captcha')){
                $where = array(
                    'username' => $username,
                    'password' => md5($password)
                );
                $cek = $this->m_model->get_where($where, 'tb_user');

                if (!empty($cek->num_rows())) {
                    foreach ($cek->result() as $dt) {
                        $user = array(
                            'id'        => $dt->id,
                            'username'  => $dt->username,
                            'nama'      => $dt->nama,
                            'level'     => $dt->level,
                        );
                    }
                    $this->session->set_userdata($user);
                    if($dt->level == 'Administrator') {
                        redirect('admin/dashboard');
                    } elseif ($dt->level == 'Siswa') {
                        redirect('siswa/dashboard');
                    }
                } else {
                    $this->session->set_flashdata('pesan', 'Username atau Password salah!');
                    redirect('home');
                }
                
            } else {
                $this->session->set_flashdata('pesan', 'Captcha salah!');
                redirect('home');
            }
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('home');
    }
}
