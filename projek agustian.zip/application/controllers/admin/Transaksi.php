<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')) {
            $this->session->set_flashdata('pesan', 'Harap login terlebih dahulu!');
			redirect('home');
		} elseif ($this->session->userdata('level') == 'Siswa') {
			redirect('siswa/dashboard');
		}
	}

	public function index()
	{
        $data['title']  = 'Data Transaksi';
        $data['transaksi'] = $this->m_model->get_desc('tb_transaksi');

		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/transaksi');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        date_default_timezone_set('Asia/Jakarta');
        $idUser = $_POST['idUser'];
        $jenis  = $_POST['jenis'];
        $jumlah = str_replace(".", "", $_POST['jumlah']);
        $tgl    = date('Y-m-d H:i:s');

        $data = array(
            'idUser'    => $idUser,
            'jenis'     => $jenis,
            'jumlah'    => $jumlah,
            'tgl'       => $tgl,
        );

        $this->m_model->insert($data, 'tb_transaksi');
        $this->session->set_flashdata('pesan', 'Transaksi berhasil ditambahkan!');
        redirect('admin/transaksi');
    }

    public function update($id)
    {
        $jenis      = $_POST['jenis'];
        $jumlah     = $_POST['jumlah'];

        $data = array(
            'jenis'     => $jenis,
            'jumlah'    => $jumlah,
        );

        $where = array('id' => $id);

        $this->m_model->update($where, $data, 'tb_transaksi');
        $this->session->set_flashdata('pesan', 'Transaksi berhasil diupdate!');
        redirect('admin/transaksi');
    }

    public function delete($id)
    {
        $where = array('id' => $id);

        $this->m_model->delete($where, 'tb_transaksi');
        $this->session->set_flashdata('pesan', 'Transaksi berhasil dihapus!');
        redirect('admin/transaksi');
    }

    public function add()
    {
        $data['title']  = 'Tambah Data Transaksi';
        $this->db->where('level', 'Siswa');
        $data['siswa']  = $this->db->get('tb_user');
        $data['transaksi'] = $this->m_model->get_desc('tb_transaksi');

        $this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/formtransaksi');
		$this->load->view('admin/templates/footer');
    }
}
