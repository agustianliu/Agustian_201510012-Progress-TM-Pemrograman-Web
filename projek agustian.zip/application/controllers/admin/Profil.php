<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')) {
			$this->session->set_flashdata('pesan', 'Harap login terlebih dahulu!');
			redirect('home');
		} elseif ($this->session->userdata('level') == 'Siswa') {
			redirect('siswa/dashboard');
		}
	}

	public function index()
	{
        $data['title'] = 'Profil';
        
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/profil');
		$this->load->view('admin/templates/footer');
	}

	public function password($id)
	{
		$password = $_POST['password'];
		$where = array('id' => $id);

		$data = array('password' => md5($password));

		$this->m_model->update($where, $data, 'tb_user');
		$this->session->set_flashdata('pesan', 'Password berhasil diganti!');
		redirect('admin/profil');
	}

	public function account($id)
	{
		$username 	= $_POST['username'];
		$nama 		= $_POST['nama'];

		$where = array('id' => $id);
		$data = array(
			'username' 	=> $username,
			'nama' 		=> $nama
		);

		$this->session->set_userdata($data);
		$this->m_model->update($where, $data, 'tb_user');
		$this->session->set_flashdata('pesan', 'Profil berhasil diubah!');
		redirect('admin/profil');
	}
}
