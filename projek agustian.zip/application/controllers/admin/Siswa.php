<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')) {
            $this->session->set_flashdata('pesan', 'Harap login terlebih dahulu!');
			redirect('home');
		} elseif ($this->session->userdata('level') == 'Siswa') {
			redirect('siswa/dashboard');
		}
	}

	public function index()
	{
        $data['title']  = 'Data Siswa';
        $data['siswa']  = $this->m_model->get_desc('tb_siswa');
        $data['kelas']  = $this->m_model->get_desc('tb_kelas');

		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/siswa');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        $nis            = $_POST['nis'];
        $nama           = $_POST['nama'];
        $tglLahir       = $_POST['tglLahir'];
        $jenisKelamin   = $_POST['jenisKelamin'];
        $idKelas        = $_POST['idKelas'];

        $data = array(
            'nama'      => $nama,
            'username'  => $nis,
            'password'  => md5($nis),
            'level'     => 'Siswa'
        );

        $this->m_model->insert($data, 'tb_user');
        $user = $this->m_model->get_where($data, 'tb_user');
        foreach ($user->result() as $idUsr) {
            $siswa = array(
                'idUser'        => $idUsr->id,
                'idKelas'       => $idKelas,
                'tglLahir'      => $tglLahir,
                'jenisKelamin'  => $jenisKelamin,
            );
        }
        $this->m_model->insert($siswa, 'tb_siswa');
        $this->session->set_flashdata('pesan', 'Siswa berhasil ditambahkan!');
        redirect('admin/siswa');
    }

    public function update()
    {
        $id             = $_POST['id'];
        $idUser         = $_POST['idUser'];
        $nis            = $_POST['nis'];
        $nama           = $_POST['nama'];
        $tglLahir       = $_POST['tglLahir'];
        $jenisKelamin   = $_POST['jenisKelamin'];
        $idKelas        = $_POST['idKelas'];

        $data = array(
            'nama'      => $nama,
            'username'  => $nis
        );

        $updateUser = array('id' => $idUser);

        $siswa = array(
            'idKelas'       => $idKelas,
            'tglLahir'      => $tglLahir,
            'jenisKelamin'  => $jenisKelamin,
        );

        $updateSiswa = array('id' => $id);

        $this->m_model->update($updateUser, $data, 'tb_user');
        $this->m_model->update($updateSiswa, $siswa, 'tb_siswa');
        $this->session->set_flashdata('pesan', 'Siswa berhasil diupdate!');
        redirect('admin/siswa');
    }

    public function delete($id)
    {
        $where = array('id' => $id);

        $user = $this->m_model->get_where($where, 'tb_siswa');
        foreach ($user->result() as $dUsr) {
            $whereUser = array('id' => $dUsr->idUser);
        }

        $this->m_model->delete($whereUser, 'tb_user');
        $this->m_model->delete($where, 'tb_siswa');
        $this->session->set_flashdata('pesan', 'Siswa berhasil dihapus!');
        redirect('admin/siswa');
    }
}
