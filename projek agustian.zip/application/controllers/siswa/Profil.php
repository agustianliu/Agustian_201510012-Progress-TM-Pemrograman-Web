<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')) {
			$this->session->set_flashdata('pesan', 'Harap login terlebih dahulu!');
			redirect('home');
		} elseif ($this->session->userdata('level') == 'Administrator') {
			redirect('admin/dashboard');
		}
	}

	public function index()
	{
		$data['title'] = 'Profil';
		$where = array('idUser' => $this->session->userdata('id'));
		$data['siswa'] = $this->m_model->get_where($where, 'tb_siswa');

		$this->load->view('siswa/templates/header', $data);
		$this->load->view('siswa/templates/sidebar');
		$this->load->view('siswa/profil');
		$this->load->view('siswa/templates/footer');
	}

	public function password($id)
	{
		$password = $_POST['password'];
		$where = array('id' => $id);

		$data = array('password' => md5($password));

		$this->m_model->update($where, $data, 'tb_user');
		$this->session->set_flashdata('pesan', 'Password berhasil diganti!');
		redirect('siswa/profil');
	}

	public function account($id)
	{
		$nama 			= $_POST['nama'];
		$tglLahir 		= $_POST['tglLahir'];
		$jenisKelamin 	= $_POST['jenisKelamin'];

		$whereUser = array('id' => $id);
		$dataUser = array('nama' 	=> $nama);
		$whereSiswa = array('idUser' => $id);
		$dataSiswa = array(
			'tglLahir' 		=> $tglLahir,
			'jenisKelamin' 	=> $jenisKelamin
		);

		$this->session->set_userdata($dataUser);
		$this->m_model->update($whereUser, $dataUser, 'tb_user');
		$this->m_model->update($whereSiswa, $dataSiswa, 'tb_siswa');
		$this->session->set_flashdata('pesan', 'Profil berhasil diubah!');
		redirect('siswa/profil');
	}
}
