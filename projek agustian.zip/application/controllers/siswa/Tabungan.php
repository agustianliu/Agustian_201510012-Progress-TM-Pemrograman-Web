<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tabungan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')) {
			$this->session->set_flashdata('pesan', 'Harap login terlebih dahulu!');
			redirect('home');
		} elseif ($this->session->userdata('level') == 'Administrator') {
			redirect('admin/dashboard');
		}
	}

	public function index()
	{
		$data['title'] 		= 'Tabungan Saya';
		$this->db->where('idUser', $this->session->userdata('id'));
		$this->db->ORDER_BY('tgl', 'DESC');
		$data['tabungan']	= $this->db->get('tb_transaksi');
		
		$this->load->view('siswa/templates/header', $data);
		$this->load->view('siswa/templates/sidebar');
		$this->load->view('siswa/tabungan');
		$this->load->view('siswa/templates/footer');
	}
}
